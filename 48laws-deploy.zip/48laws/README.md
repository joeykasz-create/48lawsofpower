# 48 Laws — Strategic Intelligence

A private AI-powered tool that analyzes real situations through Robert Greene's 48 Laws of Power framework.

## Deploy in 10 minutes

### 1. Get an Anthropic API key
- Go to https://console.anthropic.com
- Create account, add a payment method (you'll spend cents per month)
- Generate an API key, copy it

### 2. Push this folder to GitHub
- Create a free account at github.com
- Create a new repository (can be private)
- Upload all files from this folder

### 3. Deploy to Vercel
- Go to https://vercel.com, sign in with GitHub
- Click "Add New Project" and import your repository
- Before deploying, add an Environment Variable:
  - Key: `ANTHROPIC_API_KEY`
  - Value: your API key from step 1
- Click Deploy

That's it. Vercel gives you a URL like `your-project.vercel.app` that you can share with anyone.

## Privacy

- No user data is stored anywhere
- The API key lives only in Vercel's encrypted environment variables — never exposed to browsers
- No analytics, no database, no user accounts
- The server only receives the situation text, calls Claude, returns the analysis, and discards everything

## Cost estimate

Using Claude Haiku (the fastest, cheapest model):
- ~$0.001 per analysis
- 1,000 analyses = ~$1
- Extremely low cost even with heavy usage

## Files

```
/public/index.html   — the full frontend UI
/api/analyze.js      — serverless backend proxy (keeps your API key safe)
/package.json        — project config
/vercel.json         — routing config
```
