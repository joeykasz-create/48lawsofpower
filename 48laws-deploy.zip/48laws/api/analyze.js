export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { situation } = req.body;

  if (!situation || typeof situation !== "string" || situation.trim().length === 0) {
    return res.status(400).json({ error: "No situation provided" });
  }

  // Hard cap — no one can abuse this to send novels
  if (situation.length > 3000) {
    return res.status(400).json({ error: "Situation too long. Keep it under 3000 characters." });
  }

  const SYSTEM_PROMPT = `You are a strategic advisor with deep mastery of Robert Greene's 48 Laws of Power. You analyze real-life situations with precision and intellectual honesty.

When analyzing a situation, you always:
1. Identify laws being violated (by number AND name)
2. Identify laws being used against the person
3. Propose concrete counter-moves
4. Find the win-win reframe where it exists — not every situation is zero-sum
5. Speak plainly. No fluff. No hedging. No moralizing.

Format your response as a JSON object with this exact structure:
{
  "power_read": "2-3 sentence cold read of the real dynamics at play",
  "violations": [
    {
      "law_number": 1,
      "law_name": "Never Outshine the Master",
      "what_youre_doing": "specific description of the behavior",
      "cost": "what this is costing them right now",
      "counter_move": "the specific action to take"
    }
  ],
  "weapons_used_against_you": [
    {
      "law_number": 8,
      "law_name": "Make Other People Come to You",
      "how": "how the other party is using this"
    }
  ],
  "highest_leverage_move": "The single most impactful action to take right now, in 2-3 sentences.",
  "win_win_reframe": "If a collaborative solution exists, describe it. If this is genuinely adversarial, say so directly.",
  "thirty_day_play": "The strategic sequence for the next 30 days in 3-4 sentences."
}

Return ONLY valid JSON. No markdown fences. No preamble.`;

  try {
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 1500,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: "Situation: " + situation.trim() }]
      })
    });

    if (!anthropicRes.ok) {
      const err = await anthropicRes.json();
      console.error("Anthropic error:", err);
      return res.status(502).json({ error: "Analysis service unavailable. Try again." });
    }

    const data = await anthropicRes.json();
    const text = data.content?.map(b => b.text || "").join("") || "";
    const clean = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(clean);

    // Return ONLY the parsed analysis — nothing else
    return res.status(200).json(parsed);

  } catch (e) {
    console.error("Handler error:", e);
    return res.status(500).json({ error: "Something went wrong. Try again." });
  }
}
